UPDATE [IPS].[TenantInfo] SET [TenantName] = LOWER([TenantName])
