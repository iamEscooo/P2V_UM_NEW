#-------------------------------------------------
# P2V_update_userlogin




# 1  change user loginID  while userid and xkey persist

#  X-key from AD or x-key from file

$xkey="x449222"	
# get user-profile from AD 



# 1.1 select tenant(s)

# 1.2  select P2V_user to change
# 1.3  show changes
# 1.4. confirm changes
# 1.5  deploy changes



# 2 change groupname  while groupID persists
# 2.1 select tenant(s)
# 2.1 get group-name(old:new)  from file


# 1.1   select new loginID
# 1.2   sync loginID AD


# 2  select group
# 3  update group_name
