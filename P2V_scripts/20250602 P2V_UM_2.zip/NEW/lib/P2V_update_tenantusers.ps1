﻿#-----------------------------------------
# P2V_update_tenantusers 
#
#  name:   P2V_update_tenantusers.ps1 
#  ver:    1.0
#  author: M.Kufner
#
#  This script updates the information of all activated users from a tenant.
#  - No new users are added
#  - Information of existing users will be updated based on their UPN (=x-key)
#  - if users are not entitled anymore (missing AD-group memberships)
#    deactivation is suggested.`n"retrieve AD-settings for specific x-key
#
# arguments:
# $long =  false (default)   - short summary 
# $long =  true              - all AD entries
# $P2Vgroups = true (default)/false   - show P2V AD group memberships
#-----------------------------------------
param(
  [string]$tenant="",
  [bool]$lock=$False,
  [bool]$deactivate=$False,
  [bool]$checkOnly = $False,
  [bool]$debug=$False
)
#-------------------------------------------------
$My_name=[io.path]::GetFileNameWithoutExtension($($MyInvocation.MyCommand.Name))
$My_path=Split-Path $($MyInvocation.MyCommand.Path)
if (!$workdir) {$workdir=$My_Path}
. "$workdir\P2V_include.ps1"
$description="This script updates the information of all activated users from a tenant.`n- No new users are added`n- Information of existing users will be updated based on their UPN (=x-key)`n- if users are not entitled anymore (missing AD-group memberships)`n  deactivation is suggested.`n"

#----- Set config variables

$output_path = $output_path_base + "\$My_name"
createdir_ifnotexists($output_path)

#----- variables definition in P2V_include
# $spec_accounts 
 
#----- start main part
P2V_header -app $My_name -path $My_path -description $description

$tenants=select_PS_tenants -multiple $false -all $false

foreach ($ts in $tenants.keys)
{
   $t_sel  = $tenants[$ts]
   $tenant=$t_sel.tenant
   
# if(!$tenant) {$t_sel= P2V_get_tenant($tenantfile)}
# $tenant=$t_sel.tenant

# $authURL    ="$($t_sel.ServerURL)/identity/connect/token"
$base64AuthInfo = $t_sel.base64AuthInfo   #[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(("{0}:{1}" -f $t_sel.name, $t_sel.API)))
$tenantURL  ="$($t_sel.ServerURL)/$($t_sel.tenant)"
$AD_group   = $t_sel.ADgroup
$vendor_group= "dlg.WW.ADM-Services.P2V.Aucerna"

#-- select users 
$u1_list_vendor=@{}
$u1_list_P2V=@{}
$u1_list_AD =@{}

#-- get P2V user list
write-host -nonewline "|  loading users from [$tenant]`r"
$u_list_P2V=Invoke-RestMethod -Uri "$tenantURL/PlanningSpace/api/v1/users?include=UserWorkgroups" -Method GET -Headers @{'Authorization' = "Basic $base64AuthInfo"}
if (!$u_list_P2V) {$form_err -f "[ERROR]", "cannot contact $tenant !" ;exit}
$u_list_P2V= $u_list_P2V | where-Object { $_.authenticationMethod -ne "LOCAL" } 

$form_user1 -f $u_list_P2V.count, "non-local users loaded from [$tenant]","[DONE]"

#$u_list_P2V|select id,displayname,description,IsAccountLocked,isDeactivated |format-table
$u_list_P2V|% {$u1_list_P2V[$($_.logonID)]=$_}

#-- get AD -user list

#$u_list_AD =Get-ADGroupMember -Identity $AD_group|Get-ADUser -properties * |Select Surname,GivenName,Name,UserPrincipalName, Department, EmailAddress 
#$u_list_AD |% {$u1_list_AD[$($_.UserPrincipalName)]=$_}
write-host -nonewline "|  loading users from AD [$AD_group] ...`r"
$u_list_AD = get_AD_userlist -ad_group $AD_group -all $true

$form_user1 -f $u_list_AD.count, "users loaded from AD [$AD_group]","[DONE]"
$u_list_AD |% {$u1_list_AD[$($_.UserPrincipalName)]=$_}


$u_list_vendor=Get-ADGroupMember -Identity $vendor_group|Get-ADUser -properties * |Select Surname,GivenName,Name,UserPrincipalName, Department, EmailAddress 
$u_list_vendor |% {$u1_list_vendor[$($_.UserPrincipalName)]=$_}

#$u_list_AD|format-table

#$u_list_P2V|select logonID|out-gridview
#$linesep|out-host
#$u_list_AD |select UserPrincipalName|out-gridview


#--- check differences

$ccount=0
$dcount=0
$change_ops=@()
$updateOperations = @{}
$update_log= @()

$del_ops=@()
$deleteOperations = @{}
$delete_log= @()
$as_is_users = @{}
$to_be_users = @{}
$linesep
foreach ($u1 in $($u1_list_P2V.keys))
{
   if ($spec_accounts -contains $u1) {$form_status -f "* special account $u1","[SKIP]"} # skip spec. accounts (e.g. adminx449222@ww)
   else
   {
      $change_ops=@()
	  $del_ops=@()
	
      #-- get current user_profile "as-is" from tenant
     
      if ($u1_list_AD.ContainsKey($u1))
      {
         #-- user found - update infos
		 #-- get as-is profile
		 #-- define to-be profile
		
	     $u_ad   = $u1_list_AD[$u1]
	     $u_p2v  = $u1_list_P2V[$u1]
	 
         $as_is=$u1_list_P2V[$u1]|select id, logOnId, displayName, description, isDeactivated, isAccountLocked, authenticationMethod, useADEmailAddress, emailAddress  
    
         #$form1 -f "$($u_ad.UserPrincipalName) found - update details"
	  
	     #-- create update ops
  
         $descr = $u_ad.Department -replace '[,]', ''
	     $dname = "$($u_ad.Surname) $($u_ad.GivenName) ($($u_ad.name))"
         $authenticationMethod = "SAML2"
         $isDeactivated        = $False
         $isAccountLocked      = $False
         $useADEmailAddress    = $False
	  
	  if ($as_is.isDeactivated)   
	  {
	     # $form_status -f "$($as_is.logonID) deactivated","[SKIP]"
	  } else
	  {
	   
	  if ($u1_list_vendor.ContainsKey($u1))
	  { $descr = "[AUCERNA] "+$descr}
	  
	  $to_be = [PSCustomObject]@{
		    id					 = $u_p2v.id
            logOnId              = $as_is.logonID
            displayName 		 = $u_ad.displayName
            description 		 = $descr.Trim()
            isDeactivated 		 = $as_is.isDeactivated
            isAccountLocked 	 = $as_is.isAccountlocked
            authenticationMethod = "SAML2"
			useADEmailAddress    = $useADEmailAddress
			emailAddress         = $u_ad.EmailAddress
        }
	  
	#DEBUG
      # "AS-IS"
	  # $as_is|format-list|out-host
	  # "TO-BE"
	  # $to_be|format-list|out-host
	#DEBUG 
	  
	   if($as_is.displayname -ne $to_be.displayname)
	    { $change_ops += [PSCustomObject]@{  
                  op = "replace"
                  path = "/displayName"
                   value = $to_be.displayname
               } 
	    }
	   	  	  
	    if($as_is.description -ne $to_be.description)
	    {    
	      $change_ops += [PSCustomObject]@{  
                 op = "replace"
                 path = "/description"
                 value = $to_be.description
             } 
	    }
      
	    if($as_is.useADEmailAddress -ne $to_be.useADEmailAddress)
        { $change_ops += [PSCustomObject]@{
                 op = "replace"
                 path = "/useADEmailAddress"
                 value = $to_be.useADEmailAddress
			 }
        }			 
	    if($as_is.EmailAddress -ne $to_be.EmailAddress)
        { $change_ops += [PSCustomObject]@{
                 op = "replace"
                 path = "/EmailAddress"
                 value = $to_be.EmailAddress
			 }
        }		
	
	  }			
      if ($change_ops.count -gt 0)
	  {   $ccount +=1
          $update_log += ( $form_status -f "$($u_ad.UserPrincipalName) found","[UPDATE]")
	      if ($debug) {$change_ops|format-table|out-host	  }
	  } 
	} else
    { #-- user not entitled -> deactivate
   
      $u_p2v=$u1_list_P2V[$u1]
	 	  
	  
	  if (!($u_p2v.isDeactivated))
	  { 
	     $delete_log += ($form_status -f "$($u_p2v.logonID)  in P2V but not in AD","[DEACTIVATE]")
	     $del_ops += [PSCustomObject]@{
                 op = "replace"
                 path = "/isDeactivated"
                 value = "True"
         }
	     $dcount +=1 
	  }else
	  {
	   # $form_status -f "$($u_p2v.logonID)  already deactivated","[SKIP]"
	  }
     }
	 
   if ($($change_ops.count) -gt 0){ $updateOperations[$u_p2v.id.ToString()] = $change_ops  }  
   if ($($del_ops.count) -gt 0)   { $deleteOperations[$u_p2v.id.ToString()] = $del_ops  }    
   }
}
$linesep

 if ($($updateOperations.count) -gt 0)   
 {
    $update_log|% {$_|out-host}
    if (($cont=read-host ($form1 -f "update $ccount users? (y/n)")) -like "y")	 
	{  
	   $linesep|out-host
	   $form1 -f "..updating users"|out-host
	   $updateOperations |format-table|out-host
	   $body = $updateOperations |ConvertTo-Json
	   $body = [System.Text.Encoding]::UTF8.GetBytes($body)
	   if (!$checkOnly) 
       {
    	  $result = Invoke-RestMethod -Uri "$tenantURL/PlanningSpace/api/v1/users/bulk" -Method Patch -Headers @{'Authorization' = "Basic $base64AuthInfo"} -Body ($body) -ContentType "application/json" 
  	      $result  |format-list|out-host 
	   }
	}
 } else { $form1 -f "no updates required"}

if ($($deleteOperations.count) -gt 0)   
{
   $delete_log| % {$_|out-host}
   if (($cont=read-host ($form1 -f "deactivate $dcount users? (y/n)")) -like "y")	    
	{
       $linesep
	   $form1 -f "..deactivating users"
       if (!$checkOnly) 
       {
	     $result = Invoke-RestMethod -Uri "$tenantURL/PlanningSpace/api/v1/users/bulk" -Method Patch -Headers @{'Authorization' = "Basic $base64AuthInfo"} -Body ($deleteOperations|ConvertTo-Json) -ContentType "application/json"
	     $result  |format-list|out-host 	 
	   }
	}
} else { $form1 -f "no deletions required"}

}

P2V_footer -app $My_name
pause